@echo off
cd /d "%~dp0"
call npm install
if errorlevel 1 goto fail
call npm run dist
if errorlevel 1 goto fail
start "" "%~dp0dist"
goto end
:fail
echo.
echo Build failed. Read the error above.
:end
pause
