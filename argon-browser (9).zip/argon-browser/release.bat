@echo off
cd /d "%~dp0"
if "%GH_TOKEN%"=="" set /p GH_TOKEN=Paste your GitHub token: 
call npm install
if errorlevel 1 goto fail
call npm run release
if errorlevel 1 goto fail
echo.
echo Release published. Friends will update automatically.
goto end
:fail
echo.
echo Release failed. Read the error above.
:end
pause
