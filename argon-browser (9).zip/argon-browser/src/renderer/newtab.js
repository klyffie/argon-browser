if (window.argonSettings) {
  argonSettings.get().then((s) => {
    if (s) document.documentElement.style.setProperty('--accent', s.accent);
  });
  argonSettings.onChange((s) => {
    document.documentElement.style.setProperty('--accent', s.accent);
  });
}
