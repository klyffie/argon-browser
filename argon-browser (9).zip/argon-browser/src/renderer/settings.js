const api = window.argonSettings;
let current = null;
let meta = null;
let activePage = 'appearance';
let toastTimer = null;

const $ = (s) => document.querySelector(s);

function el(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') e.className = v;
      else if (k === 'text') e.textContent = v;
      else if (k === 'style') e.style.cssText = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
      else e[k] = v;
    }
  }
  for (const kid of kids.flat()) {
    if (kid != null) e.append(kid.nodeType ? kid : document.createTextNode(kid));
  }
  return e;
}

function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

function setAccent(c) {
  document.documentElement.style.setProperty('--accent', c);
}

async function save(key, value) {
  const r = await api.set({ [key]: value });
  if (r) current = r;
  if (key === 'accent') setAccent(value);
  return r;
}

async function refresh() {
  current = await api.get();
  meta = await api.meta();
  setAccent(current.accent);
}

const icons = {
  profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  appearance: '<rect x="6" y="3" width="12" height="18" rx="3"/><path d="M10 7h4"/>',
  privacy: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
  performance: '<path d="M4 18a8 8 0 1 1 16 0z"/><path d="M12 18l4-6"/>',
  search: '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
  default: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18"/>',
  startup: '<path d="M12 3v9"/><path d="M6.5 6.5a8 8 0 1 0 11 0"/>',
  languages: '<path d="M4 6h10M9 4v2M6 12c2-1 4-3 5-6M7 9c1 2 3 4 5 5M13 20l4-10 4 10M14.5 17h5"/>',
  downloads: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  accessibility: '<circle cx="12" cy="5" r="2"/><path d="M5 9l7 2 7-2M12 11v5M9 21l3-5 3 5"/>',
  system: '<path d="M14 6a4 4 0 0 0-5 5L4 16l4 4 5-5a4 4 0 0 0 5-5l-3 2-3-3z"/>',
  reset: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
  extensions: '<path d="M9 4h3v3a2 2 0 1 0 4 0V4h3v5h-3a2 2 0 1 0 0 4h3v7H4v-5h3a2 2 0 1 0 0-4H4V4z"/>',
  about: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>'
};

function svg(name) {
  const w = document.createElement('span');
  w.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + icons[name] + '</svg>';
  return w.firstChild;
}

const nav = [
  ['profiles', 'Profiles', 'profile'],
  ['appearance', 'Appearance and behavior', 'appearance'],
  ['privacy', 'Privacy and security', 'privacy'],
  ['performance', 'Performance', 'performance'],
  ['search', 'Search engine', 'search'],
  ['default', 'Default browser', 'default'],
  ['startup', 'On startup', 'startup'],
  '---',
  ['languages', 'Languages', 'languages'],
  ['downloads', 'Downloads', 'downloads'],
  ['accessibility', 'Accessibility', 'accessibility'],
  ['system', 'System', 'system'],
  ['reset', 'Reset settings', 'reset'],
  '---',
  ['extensions', 'Extensions', 'extensions'],
  ['about', 'About Argon', 'about']
];

const layouts = [
  ['classic', 'Standard'],
  ['compact', 'Compact'],
  ['vertical', 'Vertical tabs'],
  ['split', 'Split view']
];

const mocks = {
  classic: '<b style="left:4px;right:4px;top:4px;height:5px"></b><b style="left:4px;right:4px;top:12px;height:5px"></b>',
  compact: '<b style="left:4px;right:4px;top:4px;height:6px"></b>',
  vertical: '<b style="left:4px;top:4px;bottom:4px;width:14px"></b><b style="left:22px;right:4px;top:4px;height:5px"></b>',
  split: '<b style="left:4px;right:4px;top:4px;height:5px"></b><b style="left:4px;width:44%;top:14px;bottom:4px;opacity:.4"></b><b style="right:4px;width:44%;top:14px;bottom:4px;opacity:.4"></b>'
};

const languageOptions = [
  ['en-US', 'English (US)'],
  ['en-GB', 'English (UK)'],
  ['es-ES', 'Spanish'],
  ['fr-FR', 'French'],
  ['de-DE', 'German'],
  ['pt-BR', 'Portuguese (Brazil)'],
  ['it-IT', 'Italian'],
  ['ja-JP', 'Japanese'],
  ['ko-KR', 'Korean'],
  ['zh-CN', 'Chinese (Simplified)'],
  ['ru-RU', 'Russian'],
  ['nl-NL', 'Dutch'],
  ['pl-PL', 'Polish'],
  ['tr-TR', 'Turkish']
];

function layoutPicker() {
  const wrap = el('div', { class: 'layouts' });
  layouts.forEach(([id, label]) => {
    const card = el('div', { class: 'lay' + (current.layout === id ? ' sel' : '') });
    card.innerHTML = '<div class="mock">' + mocks[id] + '</div><div>' + label + '</div>';
    card.addEventListener('click', () => {
      save('layout', id);
      wrap.querySelectorAll('.lay').forEach((n) => n.classList.remove('sel'));
      card.classList.add('sel');
    });
    wrap.append(card);
  });
  return wrap;
}

function badge(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return el('span', { class: 'badge', text: name[0].toUpperCase(), style: 'background:hsl(' + h + ' 55% 42%)' });
}

function engineChoices() {
  return [...meta.engines, ...current.customEngines.map((c) => ({ id: c.id, name: c.name }))];
}

function engineName() {
  const e = engineChoices().find((x) => x.id === current.searchEngine);
  return e ? e.name : 'DuckDuckGo';
}

function openEngineDialog(onDone) {
  let chosen = current.searchEngine;
  const list = el('div', { class: 'elist' });
  engineChoices().forEach((e) => {
    const radio = el('input', { type: 'radio', name: 'eng', checked: e.id === chosen });
    radio.addEventListener('change', () => {
      chosen = e.id;
    });
    list.append(el('label', { class: 'erow' }, badge(e.name), el('span', { class: 'ename', text: e.name }), radio));
  });
  const close = () => dlg.remove();
  const dlg = el(
    'div',
    { class: 'modal' },
    el(
      'div',
      { class: 'dialog' },
      el('h3', { text: 'Search engine' }),
      el('div', { class: 'muted', text: 'Choose the search engine used in the address bar.' }),
      list,
      el(
        'div',
        { class: 'foot' },
        el('button', { class: 'pill', text: 'Cancel', onclick: close }),
        el('button', {
          class: 'pill primary',
          text: 'Set as default',
          onclick: async () => {
            await save('searchEngine', chosen);
            close();
            onDone();
          }
        })
      )
    )
  );
  dlg.addEventListener('mousedown', (ev) => {
    if (ev.target === dlg) close();
  });
  document.body.append(dlg);
}

function engineRow() {
  return el(
    'div',
    { class: 'row' },
    el('div', { class: 'lbl' }, el('div', { text: 'Search engine used in the address bar' }), el('div', { class: 'desc', text: engineName() })),
    el('button', { class: 'pill', text: 'Change', onclick: () => openEngineDialog(() => renderPage('search')) })
  );
}

function customEngines() {
  const wrap = el('div');
  current.customEngines.forEach((c) => {
    wrap.append(
      el(
        'div',
        { class: 'row' },
        el('div', { class: 'lbl' }, el('div', { text: c.name + (c.keyword ? '   !' + c.keyword : '') }), el('div', { class: 'desc', text: c.url })),
        el('button', {
          class: 'pill',
          text: 'Remove',
          onclick: async () => {
            const r = await api.set({ customEngines: current.customEngines.filter((x) => x.id !== c.id) });
            if (r) current = r;
            renderPage('search');
          }
        })
      )
    );
  });
  const name = el('input', { type: 'text', class: 'txt', placeholder: 'Name' });
  const kw = el('input', { type: 'text', class: 'txt', placeholder: 'Shortcut, e.g. ddg' });
  const url = el('input', { type: 'text', class: 'txt wide', placeholder: 'https://example.com/search?q=%s' });
  const add = el('button', {
    class: 'pill primary',
    text: 'Add search engine',
    onclick: async () => {
      if (!name.value.trim() || !/^https?:\/\/.+%s/i.test(url.value.trim())) {
        toast('Enter a name and a URL that contains %s');
        return;
      }
      const r = await api.set({
        customEngines: [...current.customEngines, { id: '', name: name.value, url: url.value, keyword: kw.value }]
      });
      if (r) current = r;
      toast('Search engine added');
      renderPage('search');
    }
  });
  wrap.append(el('div', { class: 'form' }, name, kw, url, add));
  return wrap;
}

function downloadLocation() {
  return el(
    'div',
    { class: 'row' },
    el('div', { class: 'lbl' }, el('div', { text: 'Location' }), el('div', { class: 'desc', text: current.downloadPath || meta.downloads })),
    el(
      'div',
      { class: 'inline' },
      el('button', {
        class: 'pill',
        text: 'Change',
        onclick: async () => {
          const r = await api.chooseFolder();
          if (r) {
            current = r;
            renderPage('downloads');
          }
        }
      }),
      el('button', {
        class: 'pill',
        text: 'Default',
        onclick: async () => {
          await save('downloadPath', '');
          renderPage('downloads');
        }
      })
    )
  );
}

function extensionList() {
  const wrap = el('div');
  if (!meta.extensions.length) {
    wrap.append(el('div', { class: 'row' }, el('span', { class: 'muted', text: 'No extensions installed' })));
  }
  meta.extensions.forEach((x) => {
    wrap.append(
      el(
        'div',
        { class: 'row' },
        el('div', { class: 'lbl' }, el('div', { text: x.name + ' ' + x.version }), el('div', { class: 'desc', text: x.path })),
        el('button', {
          class: 'pill',
          text: 'Remove',
          onclick: async () => {
            await api.removeExtension(x.path);
            await refresh();
            renderPage('extensions');
          }
        })
      )
    );
  });
  return wrap;
}

function pages() {
  return {
    profiles: {
      title: 'Profiles',
      groups: [
        {
          title: 'Profile',
          rows: [
            { t: 'text', k: 'profileName', label: 'Profile name', ph: 'Default' },
            { t: 'info', label: 'Profile folder', value: () => meta.userData },
            { t: 'action', label: 'Open profile folder', button: 'Open', fn: () => api.openProfile() }
          ]
        },
        {
          title: 'Backup',
          rows: [
            {
              t: 'action',
              label: 'Export settings',
              desc: 'Save your settings to a file',
              button: 'Export',
              fn: async () => {
                if (await api.exportSettings()) toast('Settings exported');
              }
            },
            {
              t: 'action',
              label: 'Import settings',
              desc: 'Load settings from a file',
              button: 'Import',
              fn: async () => {
                const r = await api.importSettings();
                if (r) {
                  await refresh();
                  renderPage('profiles');
                  toast('Settings imported');
                }
              }
            }
          ]
        }
      ]
    },
    appearance: {
      title: 'Appearance and behavior',
      groups: [
        { title: 'Layout', rows: [{ t: 'custom', label: 'Layout Standard Compact Vertical tabs Split view', render: layoutPicker }] },
        {
          title: 'Toolbar',
          rows: [
            { t: 'toggle', k: 'centeredBar', label: 'Centered address bar' },
            { t: 'toggle', k: 'minimalUrl', label: 'Minimal URL in the address bar' },
            { t: 'toggle', k: 'showHome', label: 'Show home button' },
            { t: 'text', k: 'homepage', label: 'Home page', ph: 'argon://newtab or https://…' }
          ]
        },
        {
          title: 'Appearance',
          rows: [
            { t: 'select', k: 'theme', label: 'Theme', options: [['dark', 'Dark'], ['light', 'Light'], ['system', 'System']] },
            { t: 'color', k: 'accent', label: 'Accent color' },
            { t: 'toggle', k: 'roundedFrame', label: 'Show a rounded frame around web contents' }
          ]
        }
      ]
    },
    privacy: {
      title: 'Privacy and security',
      groups: [
        {
          title: 'Protection',
          rows: [
            { t: 'toggle', k: 'blockAds', label: 'Block ads and trackers' },
            { t: 'toggle', k: 'httpsOnly', label: 'Always upgrade to HTTPS', desc: 'Local and LAN addresses are left alone' },
            { t: 'toggle', k: 'sendDnt', label: 'Send Do Not Track and Global Privacy Control' },
            { t: 'toggle', k: 'trimReferrer', label: 'Limit referrer to the site origin on cross-site requests' }
          ]
        },
        {
          title: 'Site permissions',
          rows: [
            { t: 'toggle', k: 'allowMedia', label: 'Allow sites to use the camera and microphone' },
            { t: 'toggle', k: 'allowNotifications', label: 'Allow sites to send notifications' }
          ]
        },
        {
          title: 'Browsing data',
          rows: [
            { t: 'toggle', k: 'clearOnExit', label: 'Clear cookies and site data when Argon closes' },
            {
              t: 'action',
              label: 'Clear browsing data now',
              desc: 'Cookies, site data and cached files',
              button: 'Clear data',
              fn: async () => {
                if (await api.clearData()) toast('Browsing data cleared');
              }
            }
          ]
        }
      ]
    },
    performance: {
      title: 'Performance',
      groups: [
        {
          title: 'Memory',
          rows: [
            { t: 'toggle', k: 'hibernate', label: 'Hibernate inactive tabs', desc: 'Frees memory by unloading tabs you are not using' },
            { t: 'number', k: 'hibernateMinutes', label: 'Minutes before a tab hibernates', min: 1, max: 240 }
          ]
        }
      ]
    },
    search: {
      title: 'Search engine',
      groups: [
        {
          title: 'Address bar',
          rows: [
            { t: 'custom', label: 'Search engine used in the address bar', render: engineRow },
            {
              t: 'toggle',
              k: 'bangs',
              label: 'Enable !bangs in the address bar',
              desc: 'Add !g, !yt, !w, !gh, !so, !mdn or !npm before or after your search'
            }
          ]
        },
        { title: 'Custom search engines', rows: [{ t: 'custom', label: 'Custom search engines add shortcut', render: customEngines }] }
      ]
    },
    default: {
      title: 'Default browser',
      groups: [
        {
          rows: [
            { t: 'info', label: 'Argon is the default browser', value: () => (meta.defaultBrowser ? 'Yes' : 'No') },
            {
              t: 'action',
              label: 'Make Argon the default browser',
              desc: 'Windows may ask you to confirm in its settings',
              button: 'Make default',
              fn: async () => {
                await api.setDefault();
                toast('Choose Argon in the Windows settings window');
              }
            }
          ]
        }
      ]
    },
    startup: {
      title: 'On startup',
      groups: [
        {
          rows: [
            {
              t: 'select',
              k: 'startup',
              label: 'When Argon starts',
              options: [['newtab', 'Open the New Tab page'], ['continue', 'Continue where you left off'], ['urls', 'Open specific pages']]
            },
            { t: 'area', k: 'startupUrls', label: 'Pages to open (one per line)', ph: 'https://example.com' },
            { t: 'toggle', k: 'openAtLogin', label: 'Launch Argon when I sign in to Windows' }
          ]
        }
      ]
    },
    languages: {
      title: 'Languages',
      groups: [
        {
          rows: [
            { t: 'select', k: 'language', label: 'Preferred language', options: languageOptions },
            { t: 'toggle', k: 'spellcheck', label: 'Check spelling while typing' }
          ]
        }
      ]
    },
    downloads: {
      title: 'Downloads',
      groups: [
        {
          rows: [
            { t: 'custom', label: 'Location download folder', render: downloadLocation },
            { t: 'toggle', k: 'askDownload', label: 'Ask where to save each file' },
            { t: 'toggle', k: 'showDownloaded', label: 'Show the file in its folder when a download finishes' }
          ]
        }
      ]
    },
    accessibility: {
      title: 'Accessibility',
      groups: [
        {
          rows: [
            {
              t: 'select',
              k: 'defaultZoom',
              label: 'Default page zoom',
              num: true,
              options: [50, 75, 90, 100, 110, 125, 150, 175, 200, 250, 300].map((n) => [String(n), n + '%'])
            },
            {
              t: 'select',
              k: 'minFontSize',
              label: 'Minimum font size',
              desc: 'Applies to newly opened tabs',
              num: true,
              options: [['0', 'None'], ['9', '9 px'], ['12', '12 px'], ['14', '14 px'], ['16', '16 px'], ['20', '20 px']]
            }
          ]
        }
      ]
    },
    system: {
      title: 'System',
      groups: [
        {
          rows: [
            { t: 'toggle', k: 'hardwareAcceleration', label: 'Use hardware acceleration when available', desc: 'Restart Argon after changing this' },
            {
              t: 'action',
              label: 'Restart Argon',
              button: 'Restart',
              fn: () => api.relaunch()
            }
          ]
        }
      ]
    },
    reset: {
      title: 'Reset settings',
      groups: [
        {
          rows: [
            {
              t: 'action',
              label: 'Restore settings to their original defaults',
              desc: 'Layout, search engine, privacy and other options go back to defaults. Installed extensions stay.',
              button: 'Reset settings',
              fn: async () => {
                const r = await api.reset();
                if (r) {
                  await refresh();
                  renderPage('reset');
                  toast('Settings reset');
                }
              }
            }
          ]
        }
      ]
    },
    extensions: {
      title: 'Extensions',
      groups: [
        {
          title: 'Installed',
          rows: [{ t: 'custom', label: 'Installed extensions remove', render: extensionList }]
        },
        {
          title: 'Add',
          rows: [
            {
              t: 'action',
              label: 'Load unpacked extension',
              desc: 'Chrome extensions are only partly supported',
              button: 'Choose folder',
              fn: async () => {
                await api.loadExtension();
                await refresh();
                renderPage('extensions');
              }
            }
          ]
        }
      ]
    },
    about: {
      title: 'About Argon',
      groups: [
        {
          rows: [
            { t: 'info', label: 'Version', value: () => meta.versions.app },
            { t: 'toggle', k: 'autoUpdate', label: 'Update Argon automatically' },
            { t: 'info', label: 'Update status', value: () => meta.updateStatus || 'Not checked yet' },
            {
              t: 'action',
              label: 'Check for updates',
              button: 'Check now',
              fn: async () => {
                const msg = await api.checkUpdate();
                meta = await api.meta();
                renderPage('about');
                toast(msg || 'Done');
              }
            },
            { t: 'info', label: 'Chromium', value: () => meta.versions.chrome },
            { t: 'info', label: 'Electron', value: () => meta.versions.electron },
            { t: 'info', label: 'Node.js', value: () => meta.versions.node },
            { t: 'info', label: 'V8', value: () => meta.versions.v8 },
            { t: 'info', label: 'Settings file', value: () => meta.settingsFile }
          ]
        }
      ]
    }
  };
}

function control(r) {
  if (r.t === 'toggle') {
    const i = el('input', { type: 'checkbox', class: 'sw', checked: !!current[r.k] });
    i.addEventListener('change', () => save(r.k, i.checked));
    return i;
  }
  if (r.t === 'select') {
    const s = el('select');
    r.options.forEach(([v, l]) => s.append(el('option', { value: v, text: l })));
    s.value = String(current[r.k]);
    s.addEventListener('change', () => save(r.k, r.num ? Number(s.value) : s.value));
    return s;
  }
  if (r.t === 'number') {
    const i = el('input', { type: 'number', min: r.min, max: r.max, value: current[r.k] });
    i.addEventListener('change', () => save(r.k, Number(i.value)));
    return i;
  }
  if (r.t === 'text') {
    const i = el('input', { type: 'text', class: 'txt', placeholder: r.ph || '', value: current[r.k] || '' });
    i.addEventListener('change', () => save(r.k, i.value.trim()));
    return i;
  }
  if (r.t === 'color') {
    const i = el('input', { type: 'color', value: current[r.k] });
    i.addEventListener('input', () => setAccent(i.value));
    i.addEventListener('change', () => save(r.k, i.value));
    return i;
  }
  if (r.t === 'action') {
    return el('button', { class: 'pill', text: r.button, onclick: () => r.fn() });
  }
  if (r.t === 'info') {
    return el('span', { class: 'muted', text: String(r.value()) });
  }
  return null;
}

function rowEl(r) {
  if (r.t === 'custom') return r.render();
  if (r.t === 'area') {
    const ta = el('textarea', { placeholder: r.ph || '', value: current[r.k] || '' });
    ta.addEventListener('change', () => save(r.k, ta.value));
    return el('div', { class: 'row col' }, el('div', { text: r.label }), ta);
  }
  const lbl = el('div', { class: 'lbl' }, el('div', { text: r.label }), r.desc ? el('div', { class: 'desc', text: r.desc }) : null);
  return el('div', { class: 'row' }, lbl, control(r));
}

function renderPage(id) {
  activePage = id;
  document.querySelectorAll('.link').forEach((l) => l.classList.toggle('on', l.dataset.id === id));
  const p = pages()[id];
  const root = $('#page');
  root.textContent = '';
  root.append(el('h1', { text: p.title }));
  p.groups.forEach((g) => {
    if (g.title) root.append(el('h2', { text: g.title }));
    const card = el('div', { class: 'card' });
    g.rows.forEach((r) => card.append(rowEl(r)));
    root.append(card);
  });
}

function renderSearch(q) {
  const root = $('#page');
  root.textContent = '';
  document.querySelectorAll('.link').forEach((l) => l.classList.remove('on'));
  root.append(el('h1', { text: 'Search results' }));
  const card = el('div', { class: 'card' });
  const all = pages();
  let n = 0;
  Object.values(all).forEach((p) => {
    p.groups.forEach((g) => {
      g.rows.forEach((r) => {
        const hay = ((r.label || '') + ' ' + (r.desc || '') + ' ' + (g.title || '') + ' ' + p.title).toLowerCase();
        if (r.label && hay.includes(q)) {
          card.append(rowEl(r));
          n++;
        }
      });
    });
  });
  if (!n) card.append(el('div', { class: 'row' }, el('span', { class: 'muted', text: 'No settings found' })));
  root.append(card);
}

function buildNav() {
  const links = $('#links');
  nav.forEach((item) => {
    if (item === '---') {
      links.append(el('div', { class: 'sep' }));
      return;
    }
    const [id, label, icon] = item;
    const l = el('div', { class: 'link', onclick: () => {
      $('#q').value = '';
      renderPage(id);
    } }, svg(icon), el('span', { text: label }));
    l.dataset.id = id;
    links.append(l);
  });
}

$('#q').addEventListener('input', () => {
  const q = $('#q').value.trim().toLowerCase();
  if (q) renderSearch(q);
  else renderPage(activePage);
});

api.onChange((s) => setAccent(s.accent));

refresh().then(() => {
  buildNav();
  renderPage('appearance');
});
