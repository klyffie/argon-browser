const icons = {
  back: '<path d="M15 5l-7 7 7 7"/>',
  forward: '<path d="M9 5l7 7-7 7"/>',
  reload: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
  home: '<path d="M4 11l8-7 8 7v9h-5v-6H9v6H4z"/>',
  menu: '<circle cx="12" cy="5" r="1.4"/><circle cx="12" cy="12" r="1.4"/><circle cx="12" cy="19" r="1.4"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>'
};

const $ = (id) => document.getElementById(id);

function svg(name, size) {
  const s = size || 16;
  return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + icons[name] + '</svg>';
}

document.querySelectorAll('[data-icon]').forEach((b) => {
  b.innerHTML = svg(b.dataset.icon);
});

const urlInput = $('url');
const tabsEl = $('tabs');
const newTabBtn = $('newtab');
let state = null;

function ph() {
  const s = document.createElement('span');
  s.className = 'ph';
  return s;
}

function shown(s) {
  const t = s.tabs.find((x) => x.id === s.activeId);
  if (!t || t.url === 'argon://newtab') return '';
  if (s.settings.minimalUrl && /^https?:\/\//i.test(t.url)) {
    try {
      return new URL(t.url).hostname.replace(/^www\./, '');
    } catch {
      return t.url;
    }
  }
  return t.url;
}

function fullUrl(s) {
  const t = s.tabs.find((x) => x.id === s.activeId);
  return !t || t.url === 'argon://newtab' ? '' : t.url;
}

function tabEl(t, s) {
  const el = document.createElement('div');
  el.className = 'tab' +
    (t.id === s.activeId ? ' active' : '') +
    (s.settings.layout === 'split' && t.id === s.splitId ? ' pane' : '') +
    (t.hibernated ? ' hib' : '') +
    (t.loading ? ' loading' : '');
  el.title = t.title || t.url;
  let ic;
  if (t.favicon && !t.loading) {
    ic = document.createElement('img');
    ic.src = t.favicon;
    ic.alt = '';
    ic.onerror = () => ic.replaceWith(ph());
  } else {
    ic = ph();
  }
  const title = document.createElement('span');
  title.className = 't';
  title.textContent = t.title || t.url;
  const x = document.createElement('button');
  x.className = 'x';
  x.innerHTML = svg('close', 12);
  x.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    if (e.button === 0) argon.send('tab:close', t.id);
  });
  el.append(ic, title, x);
  el.addEventListener('mousedown', (e) => {
    if (e.button === 1) {
      e.preventDefault();
      argon.send('tab:close', t.id);
    } else if (e.button === 0) {
      argon.send('tab:activate', t.id);
    }
  });
  return el;
}

function render(s) {
  state = s;
  const st = s.settings;
  document.body.dataset.layout = st.layout;
  document.body.classList.toggle('centered', st.centeredBar);
  document.documentElement.style.setProperty('--accent', st.accent);
  $('home').hidden = !st.showHome;
  $('back').disabled = !s.canGoBack;
  $('forward').disabled = !s.canGoForward;
  tabsEl.querySelectorAll('.tab').forEach((e) => e.remove());
  s.tabs.forEach((t) => tabsEl.insertBefore(tabEl(t, s), newTabBtn));
  if (document.activeElement !== urlInput) urlInput.value = shown(s);
}

argon.onState(render);

argon.onFocusOmnibox(() => {
  urlInput.focus();
  urlInput.select();
});

urlInput.addEventListener('focus', () => {
  if (state) urlInput.value = fullUrl(state);
  urlInput.select();
});

urlInput.addEventListener('blur', () => {
  if (state) urlInput.value = shown(state);
});

urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    argon.send('nav:go', urlInput.value);
    urlInput.blur();
  } else if (e.key === 'Escape') {
    urlInput.blur();
  }
});

$('back').addEventListener('click', () => argon.send('nav:back'));
$('forward').addEventListener('click', () => argon.send('nav:forward'));
$('reload').addEventListener('click', () => argon.send('nav:reload'));
$('home').addEventListener('click', () => argon.send('nav:home'));
$('menu').addEventListener('click', () => argon.send('menu:open'));
newTabBtn.addEventListener('click', () => argon.send('tab:new'));
tabsEl.addEventListener('dblclick', (e) => {
  if (e.target === tabsEl) argon.send('tab:new');
});
