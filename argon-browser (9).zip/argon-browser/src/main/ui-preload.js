const { contextBridge, ipcRenderer } = require('electron');

const allowed = new Set([
  'tab:new',
  'tab:activate',
  'tab:close',
  'nav:go',
  'nav:back',
  'nav:forward',
  'nav:reload',
  'nav:home',
  'menu:open'
]);

contextBridge.exposeInMainWorld('argon', {
  onState: (cb) => ipcRenderer.on('state', (e, s) => cb(s)),
  onFocusOmnibox: (cb) => ipcRenderer.on('focus-omnibox', () => cb()),
  send: (channel, ...args) => {
    if (allowed.has(channel)) ipcRenderer.send(channel, ...args);
  }
});
