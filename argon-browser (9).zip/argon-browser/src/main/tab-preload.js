const { contextBridge, ipcRenderer } = require('electron');

if (location.protocol === 'file:') {
  contextBridge.exposeInMainWorld('argonSettings', {
    get: () => ipcRenderer.invoke('settings:get'),
    set: (patch) => ipcRenderer.invoke('settings:set', patch),
    meta: () => ipcRenderer.invoke('settings:meta'),
    onChange: (cb) => ipcRenderer.on('settings-changed', (e, s) => cb(s)),
    loadExtension: () => ipcRenderer.invoke('ext:load'),
    removeExtension: (p) => ipcRenderer.invoke('ext:remove', p),
    chooseFolder: () => ipcRenderer.invoke('dl:choose'),
    openProfile: () => ipcRenderer.invoke('path:open'),
    clearData: () => ipcRenderer.invoke('privacy:clear'),
    reset: () => ipcRenderer.invoke('settings:reset'),
    exportSettings: () => ipcRenderer.invoke('settings:export'),
    importSettings: () => ipcRenderer.invoke('settings:import'),
    setDefault: () => ipcRenderer.invoke('browser:default'),
    relaunch: () => ipcRenderer.invoke('app:relaunch'),
    checkUpdate: () => ipcRenderer.invoke('update:check')
  });
}
