const {
  app,
  BrowserWindow,
  WebContentsView,
  ipcMain,
  session,
  Menu,
  nativeTheme,
  dialog,
  clipboard,
  shell
} = require('electron');
const path = require('path');
const fs = require('fs');
const { pathToFileURL } = require('url');
const { ElectronBlocker } = require('@ghostery/adblocker-electron');

const rendererDir = path.join(__dirname, '..', 'renderer');
const rendererURL = pathToFileURL(rendererDir).href + '/';
const internal = {
  settings: pathToFileURL(path.join(rendererDir, 'settings.html')).href,
  newtab: pathToFileURL(path.join(rendererDir, 'newtab.html')).href
};

const defaults = {
  profileName: 'Default',
  theme: 'dark',
  accent: '#4f5bd5',
  layout: 'classic',
  centeredBar: false,
  minimalUrl: false,
  roundedFrame: true,
  showHome: false,
  homepage: 'argon://newtab',
  blockAds: true,
  httpsOnly: true,
  sendDnt: true,
  trimReferrer: true,
  allowMedia: true,
  allowNotifications: false,
  clearOnExit: false,
  hibernate: true,
  hibernateMinutes: 10,
  hardwareAcceleration: true,
  searchEngine: 'duckduckgo',
  bangs: true,
  customEngines: [],
  startup: 'newtab',
  startupUrls: '',
  openAtLogin: false,
  language: 'en-US',
  spellcheck: true,
  downloadPath: '',
  askDownload: false,
  showDownloaded: true,
  defaultZoom: 100,
  minFontSize: 0,
  autoUpdate: true,
  extensions: []
};

const builtinEngines = [
  { id: 'duckduckgo', name: 'DuckDuckGo', url: 'https://duckduckgo.com/?q=%s' },
  { id: 'brave', name: 'Brave Search', url: 'https://search.brave.com/search?q=%s' },
  { id: 'bing', name: 'Microsoft Bing', url: 'https://www.bing.com/search?q=%s' },
  { id: 'startpage', name: 'Startpage', url: 'https://www.startpage.com/do/search?q=%s' },
  { id: 'ecosia', name: 'Ecosia', url: 'https://www.ecosia.org/search?q=%s' },
  { id: 'google', name: 'Google', url: 'https://www.google.com/search?q=%s' },
  { id: 'kagi', name: 'Kagi', url: 'https://kagi.com/search?q=%s' },
  { id: 'qwant', name: 'Qwant', url: 'https://www.qwant.com/?q=%s' },
  { id: 'yahoo', name: 'Yahoo', url: 'https://search.yahoo.com/search?p=%s' }
];

const bangs = {
  g: 'https://www.google.com/search?q=%s',
  ddg: 'https://duckduckgo.com/?q=%s',
  yt: 'https://www.youtube.com/results?search_query=%s',
  w: 'https://en.wikipedia.org/w/index.php?search=%s',
  gh: 'https://github.com/search?q=%s',
  a: 'https://www.amazon.com/s?k=%s',
  r: 'https://www.reddit.com/search/?q=%s',
  so: 'https://stackoverflow.com/search?q=%s',
  mdn: 'https://developer.mozilla.org/en-US/search?q=%s',
  npm: 'https://www.npmjs.com/search?q=%s',
  maps: 'https://www.google.com/maps/search/%s',
  imdb: 'https://www.imdb.com/find?q=%s',
  x: 'https://x.com/search?q=%s'
};

const metrics = {
  classic: { top: 82, left: 0 },
  split: { top: 82, left: 0 },
  compact: { top: 46, left: 0 },
  vertical: { top: 46, left: 220 }
};

const languages = [
  'en-US', 'en-GB', 'es-ES', 'fr-FR', 'de-DE', 'pt-BR', 'it-IT',
  'ja-JP', 'ko-KR', 'zh-CN', 'ru-RU', 'nl-NL', 'pl-PL', 'tr-TR'
];

let settings = { ...defaults };
let win = null;
let blocker = null;
let activeId = null;
let splitId = null;
let nextId = 1;
let uaBase = '';
let saveTimer = null;
let cleaning = false;
let updater = null;
let updateStatus = '';
const tabs = new Map();

function settingsFile() {
  return path.join(app.getPath('userData'), 'settings.json');
}

function sessionFile() {
  return path.join(app.getPath('userData'), 'session.json');
}

function clamp(n, lo, hi) {
  return Math.min(hi, Math.max(lo, n));
}

function cleanEngines(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((c) => c && typeof c.name === 'string' && typeof c.url === 'string' && /^https?:\/\/.+%s/i.test(c.url.trim()))
    .slice(0, 30)
    .map((c) => ({
      id: typeof c.id === 'string' && /^c_[a-z0-9]+$/.test(c.id) ? c.id : 'c_' + Math.random().toString(36).slice(2, 9),
      name: c.name.trim().slice(0, 40) || 'Custom',
      url: c.url.trim().slice(0, 500),
      keyword: typeof c.keyword === 'string' ? c.keyword.trim().replace(/^!/, '').replace(/[^a-z0-9]/gi, '').slice(0, 16) : ''
    }));
}

function sanitize(patch) {
  const out = {};
  for (const k of Object.keys(patch || {})) {
    if (!(k in defaults)) continue;
    const v = patch[k];
    if (k === 'customEngines') {
      out[k] = cleanEngines(v);
      continue;
    }
    if (k === 'extensions') {
      if (Array.isArray(v)) out[k] = v.filter((x) => typeof x === 'string');
      continue;
    }
    if (typeof v !== typeof defaults[k]) continue;
    out[k] = v;
  }
  if ('hibernateMinutes' in out) out.hibernateMinutes = clamp(Math.round(out.hibernateMinutes) || 10, 1, 240);
  if ('defaultZoom' in out) out.defaultZoom = clamp(Math.round(out.defaultZoom) || 100, 50, 300);
  if ('minFontSize' in out) out.minFontSize = clamp(Math.round(out.minFontSize) || 0, 0, 32);
  if ('layout' in out && !metrics[out.layout]) delete out.layout;
  if ('theme' in out && !['dark', 'light', 'system'].includes(out.theme)) delete out.theme;
  if ('startup' in out && !['newtab', 'continue', 'urls'].includes(out.startup)) delete out.startup;
  if ('language' in out && !languages.includes(out.language)) delete out.language;
  if ('accent' in out && !/^#[0-9a-f]{6}$/i.test(out.accent)) delete out.accent;
  if ('profileName' in out) out.profileName = out.profileName.slice(0, 40);
  if ('startupUrls' in out) out.startupUrls = out.startupUrls.slice(0, 5000);
  if ('homepage' in out) out.homepage = out.homepage.slice(0, 500);
  if ('downloadPath' in out) out.downloadPath = out.downloadPath.slice(0, 500);
  return out;
}

function engineList() {
  return [
    ...builtinEngines,
    ...settings.customEngines.map((c) => ({ id: c.id, name: c.name, url: c.url, custom: true, keyword: c.keyword }))
  ];
}

function currentEngine() {
  return engineList().find((e) => e.id === settings.searchEngine) || builtinEngines[0];
}

function bangMap() {
  const m = { ...bangs };
  for (const c of settings.customEngines) {
    if (c.keyword) m[c.keyword.toLowerCase()] = c.url;
  }
  return m;
}

function loadSettings() {
  try {
    settings = { ...defaults, ...sanitize(JSON.parse(fs.readFileSync(settingsFile(), 'utf8'))) };
  } catch {
    settings = { ...defaults };
  }
  if (!engineList().some((e) => e.id === settings.searchEngine)) settings.searchEngine = 'duckduckgo';
}

function saveSettings() {
  try {
    fs.mkdirSync(path.dirname(settingsFile()), { recursive: true });
    fs.writeFileSync(settingsFile(), JSON.stringify(settings, null, 2));
  } catch {}
}

loadSettings();

if (!settings.hardwareAcceleration) app.disableHardwareAcceleration();

app.commandLine.appendSwitch('disable-background-networking');
app.commandLine.appendSwitch('disable-sync');
app.commandLine.appendSwitch('no-pings');
app.commandLine.appendSwitch('disable-breakpad');
app.commandLine.appendSwitch('disable-component-update');
app.commandLine.appendSwitch('disable-features', 'Translate,MediaRouter,OptimizationHints,InterestFeedContentSuggestions,AutofillServerCommunication');
app.commandLine.appendSwitch('enable-gpu-rasterization');
app.commandLine.appendSwitch('enable-zero-copy');

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

app.setAppUserModelId('com.redraid.argon');

function isLocal(url) {
  try {
    const h = new URL(url).hostname;
    return (
      h === 'localhost' ||
      h === '127.0.0.1' ||
      h === '[::1]' ||
      h.endsWith('.local') ||
      /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(h)
    );
  } catch {
    return true;
  }
}

function displayUrl(url) {
  for (const [k, v] of Object.entries(internal)) {
    if (url.startsWith(v)) return 'argon://' + k;
  }
  return url;
}

function resolveInput(raw) {
  const text = String(raw || '').trim();
  if (!text) return internal.newtab;
  const m = text.match(/^argon:\/\/(\w+)/i);
  if (m && internal[m[1].toLowerCase()]) return internal[m[1].toLowerCase()];
  if (settings.bangs) {
    const map = bangMap();
    const parts = text.split(/\s+/);
    const i = parts.findIndex((p) => /^![a-z0-9]+$/i.test(p) && map[p.slice(1).toLowerCase()]);
    if (i >= 0) {
      const key = parts[i].slice(1).toLowerCase();
      const q = parts.filter((_, j) => j !== i).join(' ');
      return map[key].split('%s').join(encodeURIComponent(q));
    }
  }
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(text)) return text;
  if (/^(localhost|(\d{1,3}\.){3}\d{1,3})(:\d+)?(\/.*)?$/i.test(text)) return 'http://' + text;
  if (/^[^\s]+\.[a-z]{2,}(:\d+)?(\/\S*)?$/i.test(text)) return 'https://' + text;
  return currentEngine().url.split('%s').join(encodeURIComponent(text));
}

function overlay() {
  const dark = nativeTheme.shouldUseDarkColors;
  return {
    color: dark ? '#1a1a1c' : '#e8e9ee',
    symbolColor: dark ? '#e8e8ea' : '#1b1b1f',
    height: settings.layout === 'classic' || settings.layout === 'split' ? 38 : 46
  };
}

function fromInternal(e) {
  const url = (e.senderFrame && e.senderFrame.url) || '';
  return url.startsWith(rendererURL);
}

function createView(tab) {
  const view = new WebContentsView({
    webPreferences: {
      preload: path.join(__dirname, 'tab-preload.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: true,
      minimumFontSize: settings.minFontSize
    }
  });
  const wc = view.webContents;
  tab.view = view;
  tab.hibernated = false;

  wc.setWindowOpenHandler(({ url }) => {
    createTab(url);
    return { action: 'deny' };
  });
  wc.on('page-title-updated', (e, title) => {
    tab.title = title;
    push();
  });
  wc.on('page-favicon-updated', (e, icons) => {
    tab.favicon = icons[0] || '';
    push();
  });
  wc.on('did-start-loading', () => {
    tab.loading = true;
    push();
  });
  wc.on('did-stop-loading', () => {
    tab.loading = false;
    push();
  });
  wc.on('dom-ready', () => {
    if (tab.url.startsWith(rendererURL) || tab.userZoom) return;
    wc.setZoomFactor(settings.defaultZoom / 100);
  });
  const nav = (e, url) => {
    tab.url = url;
    push();
  };
  wc.on('did-navigate', nav);
  wc.on('did-navigate-in-page', nav);
  const upgrade = (e, url) => {
    if (settings.httpsOnly && /^http:\/\//i.test(url) && !isLocal(url)) {
      e.preventDefault();
      wc.loadURL(url.replace(/^http:/i, 'https:')).catch(() => {});
    }
  };
  wc.on('will-navigate', upgrade);
  wc.on('will-redirect', upgrade);
  wc.on('before-input-event', handleKey);
  wc.on('context-menu', (e, p) => {
    const items = [];
    if (p.linkURL) {
      items.push(
        { label: 'Open link in new tab', click: () => createTab(p.linkURL) },
        { label: 'Copy link address', click: () => clipboard.writeText(p.linkURL) },
        { type: 'separator' }
      );
    }
    if (p.isEditable) {
      items.push({ role: 'cut' }, { role: 'copy' }, { role: 'paste' }, { type: 'separator' });
    } else if (p.selectionText) {
      items.push({ role: 'copy' }, { type: 'separator' });
    }
    items.push(
      { label: 'Back', enabled: wc.navigationHistory.canGoBack(), click: () => wc.navigationHistory.goBack() },
      { label: 'Forward', enabled: wc.navigationHistory.canGoForward(), click: () => wc.navigationHistory.goForward() },
      { label: 'Reload', click: () => wc.reload() },
      { type: 'separator' },
      { label: 'Inspect', click: () => wc.inspectElement(p.x, p.y) }
    );
    Menu.buildFromTemplate(items).popup({ window: win });
  });
  return view;
}

function ensureView(tab) {
  if (tab.view) return;
  createView(tab);
  tab.view.webContents.loadURL(tab.url).catch(() => {});
}

function createTab(url, opts = {}) {
  const activate = opts.activate !== false;
  const id = nextId++;
  const tab = {
    id,
    url,
    title: opts.title || 'New Tab',
    favicon: '',
    loading: false,
    view: null,
    hibernated: false,
    userZoom: false,
    lastActive: Date.now()
  };
  tabs.set(id, tab);
  if (opts.lazy) {
    tab.hibernated = true;
  } else {
    createView(tab);
    tab.view.webContents.loadURL(url).catch(() => {});
  }
  if (activate) activateTab(id);
  else push();
  return tab;
}

function ensureSplit() {
  if (settings.layout !== 'split') {
    splitId = null;
    return;
  }
  if (splitId && tabs.has(splitId) && splitId !== activeId) return;
  const other = [...tabs.values()].find((t) => t.id !== activeId);
  if (other) {
    splitId = other.id;
    return;
  }
  const t = createTab(internal.newtab, { activate: false });
  splitId = t.id;
}

function applyLayout() {
  if (!win || win.isDestroyed()) return;
  const [w, h] = win.getContentSize();
  const m = metrics[settings.layout] || metrics.classic;
  const pad = settings.roundedFrame ? 6 : 0;
  const x = m.left + pad;
  const y = m.top;
  const cw = Math.max(0, w - m.left - pad * 2);
  const ch = Math.max(0, h - m.top - pad);
  for (const c of [...win.contentView.children]) win.contentView.removeChildView(c);
  const panes = [];
  const a = tabs.get(activeId);
  if (a) panes.push(a);
  if (settings.layout === 'split') {
    const s = tabs.get(splitId);
    if (s && s !== a) panes.push(s);
  }
  const gap = panes.length > 1 ? 6 : 0;
  const pw = Math.floor((cw - gap * (panes.length - 1)) / Math.max(1, panes.length));
  panes.forEach((t, i) => {
    ensureView(t);
    t.lastActive = Date.now();
    t.view.setBounds({ x: x + i * (pw + gap), y, width: pw, height: ch });
    if (t.view.setBorderRadius) t.view.setBorderRadius(settings.roundedFrame ? 8 : 0);
    win.contentView.addChildView(t.view);
  });
}

function activateTab(id) {
  const t = tabs.get(id);
  if (!t) return;
  const prev = tabs.get(activeId);
  if (prev) prev.lastActive = Date.now();
  if (id === splitId) splitId = activeId;
  activeId = id;
  ensureSplit();
  applyLayout();
  push();
  if (t.url.startsWith(internal.newtab)) {
    win.webContents.focus();
    win.webContents.send('focus-omnibox');
  } else if (t.view) {
    t.view.webContents.focus();
  }
}

function closeTab(id) {
  const t = tabs.get(id);
  if (!t) return;
  const order = [...tabs.keys()];
  const idx = order.indexOf(id);
  if (t.view) {
    try {
      win.contentView.removeChildView(t.view);
    } catch {}
    t.view.webContents.close();
  }
  tabs.delete(id);
  if (splitId === id) splitId = null;
  if (tabs.size === 0) {
    win.close();
    return;
  }
  if (activeId === id) {
    const rest = [...tabs.keys()];
    activeId = null;
    activateTab(rest[Math.min(idx, rest.length - 1)]);
  } else {
    ensureSplit();
    applyLayout();
    push();
  }
}

function cycle(d) {
  const ids = [...tabs.keys()];
  const i = ids.indexOf(activeId);
  activateTab(ids[(i + d + ids.length) % ids.length]);
}

function activeTab() {
  return tabs.get(activeId) || null;
}

function activeContents() {
  const t = activeTab();
  return t && t.view ? t.view.webContents : null;
}

function openSettings() {
  const existing = [...tabs.values()].find((t) => t.url.startsWith(internal.settings));
  if (existing) activateTab(existing.id);
  else createTab(internal.settings);
}

function navigateActive(text) {
  const t = activeTab();
  if (!t) return;
  const url = resolveInput(text);
  t.url = url;
  t.userZoom = false;
  ensureView(t);
  t.view.webContents.loadURL(url).catch(() => {});
  if (!url.startsWith(internal.newtab)) t.view.webContents.focus();
  push();
}

function sessionData() {
  const list = [...tabs.values()].filter((t) => !t.url.startsWith(rendererURL));
  const idx = list.findIndex((t) => t.id === activeId);
  return { urls: list.map((t) => t.url), active: idx < 0 ? 0 : idx };
}

function flushSession() {
  clearTimeout(saveTimer);
  try {
    fs.mkdirSync(path.dirname(sessionFile()), { recursive: true });
    fs.writeFileSync(sessionFile(), JSON.stringify(sessionData()));
  } catch {}
}

function scheduleSession() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSession, 800);
}

function push() {
  if (!win || win.isDestroyed()) return;
  const wc = activeContents();
  win.webContents.send('state', {
    tabs: [...tabs.values()].map((t) => ({
      id: t.id,
      title: t.title,
      url: displayUrl(t.url),
      favicon: t.favicon,
      loading: t.loading,
      hibernated: t.hibernated
    })),
    activeId,
    splitId,
    canGoBack: !!wc && wc.navigationHistory.canGoBack(),
    canGoForward: !!wc && wc.navigationHistory.canGoForward(),
    settings
  });
  scheduleSession();
}

function handleKey(e, input) {
  if (input.type !== 'keyDown') return;
  const c = input.control || input.meta;
  const k = input.key.toLowerCase();
  const act = (fn) => {
    e.preventDefault();
    fn();
  };
  if (c && !input.shift && k === 't') return act(() => createTab(internal.newtab));
  if (c && k === 'w') return act(() => closeTab(activeId));
  if (c && k === 'l') {
    return act(() => {
      win.webContents.focus();
      win.webContents.send('focus-omnibox');
    });
  }
  if ((c && k === 'r') || k === 'f5') {
    return act(() => {
      const wc = activeContents();
      if (wc) wc.reload();
    });
  }
  if (c && k === ',') return act(openSettings);
  if (c && k === 'tab') return act(() => cycle(input.shift ? -1 : 1));
  if (input.alt && k === 'arrowleft') {
    return act(() => {
      const wc = activeContents();
      if (wc) wc.navigationHistory.goBack();
    });
  }
  if (input.alt && k === 'arrowright') {
    return act(() => {
      const wc = activeContents();
      if (wc) wc.navigationHistory.goForward();
    });
  }
  if (c && /^[1-9]$/.test(k)) {
    return act(() => {
      const ids = [...tabs.keys()];
      const n = Number(k);
      activateTab(n === 9 ? ids[ids.length - 1] : ids[n - 1]);
    });
  }
  if (k === 'f12') {
    return act(() => {
      const wc = activeContents();
      if (wc) wc.openDevTools({ mode: 'detach' });
    });
  }
}

async function loadUnpacked() {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory'] });
  if (r.canceled || !r.filePaths[0]) return;
  const p = r.filePaths[0];
  try {
    await session.defaultSession.extensions.loadExtension(p, { allowFileAccess: true });
    if (!settings.extensions.includes(p)) updateSettings({ extensions: [...settings.extensions, p] });
  } catch (err) {
    dialog.showErrorBox('Extension failed', String((err && err.message) || err));
  }
}

async function loadSavedExtensions() {
  for (const p of settings.extensions) {
    try {
      await session.defaultSession.extensions.loadExtension(p, { allowFileAccess: true });
    } catch {}
  }
}

async function clearBrowsingData() {
  const ses = session.defaultSession;
  try {
    await ses.clearStorageData();
    await ses.clearCache();
    await ses.clearHostResolverCache();
  } catch {}
}

function showMenu() {
  const zoom = (d) => {
    const t = activeTab();
    const c = activeContents();
    if (!c) return;
    t.userZoom = true;
    c.setZoomLevel(d === 0 ? 0 : c.getZoomLevel() + d);
  };
  Menu.buildFromTemplate([
    { label: 'New tab', accelerator: 'Ctrl+T', click: () => createTab(internal.newtab) },
    { type: 'separator' },
    { label: 'Zoom in', click: () => zoom(0.5) },
    { label: 'Zoom out', click: () => zoom(-0.5) },
    { label: 'Reset zoom', click: () => zoom(0) },
    {
      label: 'Print…',
      accelerator: 'Ctrl+P',
      click: () => {
        const c = activeContents();
        if (c) c.print();
      }
    },
    { type: 'separator' },
    { label: 'Load unpacked extension…', click: loadUnpacked },
    {
      label: 'Developer tools',
      accelerator: 'F12',
      click: () => {
        const c = activeContents();
        if (c) c.openDevTools({ mode: 'detach' });
      }
    },
    { label: 'Check for updates…', click: checkUpdatesNow },
    { label: 'Settings', accelerator: 'Ctrl+,', click: openSettings },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]).popup({ window: win });
}

function registerHeaderHook() {
  session.defaultSession.webRequest.onBeforeSendHeaders((details, cb) => {
    const h = details.requestHeaders;
    if (settings.sendDnt) {
      h['DNT'] = '1';
      h['Sec-GPC'] = '1';
    }
    if (settings.trimReferrer && h['Referer']) {
      try {
        const r = new URL(h['Referer']);
        const t = new URL(details.url);
        if (r.origin !== t.origin) h['Referer'] = r.origin + '/';
      } catch {}
    }
    cb({ requestHeaders: h });
  });
}

function applyBlocker() {
  if (blocker) {
    const ses = session.defaultSession;
    if (settings.blockAds) blocker.enableBlockingInSession(ses);
    else blocker.disableBlockingInSession(ses);
  }
  registerHeaderHook();
}

async function initBlocker() {
  try {
    blocker = await ElectronBlocker.fromPrebuiltAdsAndTracking(fetch, {
      path: path.join(app.getPath('userData'), 'engine.bin'),
      read: fs.promises.readFile,
      write: fs.promises.writeFile
    });
  } catch {}
  applyBlocker();
}

function applyLanguage() {
  const ses = session.defaultSession;
  try {
    ses.setUserAgent(uaBase, settings.language + ',' + settings.language.split('-')[0]);
    ses.setSpellCheckerEnabled(settings.spellcheck);
    const avail = ses.availableSpellCheckerLanguages;
    const base = settings.language.split('-')[0];
    const pick = avail.includes(settings.language) ? settings.language : avail.includes(base) ? base : 'en-US';
    ses.setSpellCheckerLanguages([pick]);
  } catch {}
}

function uniquePath(dir, name) {
  const ext = path.extname(name);
  const base = path.basename(name, ext);
  let p = path.join(dir, name);
  let n = 1;
  while (fs.existsSync(p)) p = path.join(dir, base + ' (' + n++ + ')' + ext);
  return p;
}

function setupDownloads() {
  session.defaultSession.on('will-download', (e, item) => {
    if (!settings.askDownload) {
      const dir = settings.downloadPath || app.getPath('downloads');
      try {
        fs.mkdirSync(dir, { recursive: true });
      } catch {}
      item.setSavePath(uniquePath(dir, item.getFilename()));
    }
    item.once('done', (ev, state) => {
      if (state === 'completed' && settings.showDownloaded) shell.showItemInFolder(item.getSavePath());
    });
  });
}

function setupPermissions() {
  const ses = session.defaultSession;
  const ok = (perm) => {
    if (['fullscreen', 'clipboard-sanitized-write', 'pointerLock'].includes(perm)) return true;
    if (perm === 'media') return settings.allowMedia;
    if (perm === 'notifications') return settings.allowNotifications;
    return false;
  };
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(ok(perm)));
  ses.setPermissionCheckHandler((wc, perm) => ok(perm));
}

function broadcastSettings() {
  for (const t of tabs.values()) {
    if (t.view && t.url.startsWith(rendererURL)) t.view.webContents.send('settings-changed', settings);
  }
}

function updateSettings(patch) {
  const prev = settings;
  settings = { ...settings, ...sanitize(patch) };
  if (!engineList().some((e) => e.id === settings.searchEngine)) settings.searchEngine = 'duckduckgo';
  saveSettings();
  nativeTheme.themeSource = settings.theme;
  if (settings.blockAds !== prev.blockAds) applyBlocker();
  if (settings.openAtLogin !== prev.openAtLogin) {
    try {
      app.setLoginItemSettings({ openAtLogin: settings.openAtLogin });
    } catch {}
  }
  if (settings.language !== prev.language || settings.spellcheck !== prev.spellcheck) applyLanguage();
  if (settings.defaultZoom !== prev.defaultZoom) {
    for (const t of tabs.values()) {
      if (t.view && !t.userZoom && !t.url.startsWith(rendererURL)) t.view.webContents.setZoomFactor(settings.defaultZoom / 100);
    }
  }
  if (settings.layout !== prev.layout) {
    ensureSplit();
    if (win) win.setTitleBarOverlay(overlay());
  }
  applyLayout();
  push();
  broadcastSettings();
}

function setupUpdater() {
  if (!app.isPackaged) return;
  const { autoUpdater } = require('electron-updater');
  autoUpdater.autoDownload = true;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.on('checking-for-update', () => {
    updateStatus = 'Checking for updates…';
  });
  autoUpdater.on('update-available', (i) => {
    updateStatus = 'Downloading version ' + i.version + '…';
  });
  autoUpdater.on('update-not-available', () => {
    updateStatus = 'Argon is up to date';
  });
  autoUpdater.on('download-progress', (p) => {
    updateStatus = 'Downloading update… ' + Math.round(p.percent) + '%';
  });
  autoUpdater.on('error', () => {
    updateStatus = 'Update check failed';
  });
  autoUpdater.on('update-downloaded', async (i) => {
    updateStatus = 'Version ' + i.version + ' is ready to install';
    const r = await dialog.showMessageBox(win, {
      type: 'info',
      buttons: ['Restart now', 'Later'],
      defaultId: 0,
      cancelId: 1,
      title: 'Update ready',
      message: 'Argon ' + i.version + ' is ready to install.',
      detail: 'It will also install automatically the next time you close Argon.'
    });
    if (r.response === 0) autoUpdater.quitAndInstall();
  });
  updater = autoUpdater;
  const check = () => {
    if (settings.autoUpdate) autoUpdater.checkForUpdates().catch(() => {});
  };
  setTimeout(check, 15000);
  setInterval(check, 4 * 3600 * 1000);
}

async function checkUpdatesNow() {
  if (!updater) {
    dialog.showMessageBox(win, { type: 'info', message: 'Updates only work in the installed app' });
    return;
  }
  try {
    await updater.checkForUpdates();
  } catch {
    updateStatus = 'Update check failed';
  }
  if (updateStatus === 'Argon is up to date' || updateStatus === 'Update check failed') {
    dialog.showMessageBox(win, { type: 'info', message: updateStatus });
  } else if (updateStatus.startsWith('Downloading')) {
    dialog.showMessageBox(win, {
      type: 'info',
      message: 'Update found',
      detail: 'It is downloading now. Argon will ask you to restart when it is ready.'
    });
  }
}

function startHibernation() {
  setInterval(() => {
    if (!settings.hibernate) return;
    const limit = settings.hibernateMinutes * 60000;
    const now = Date.now();
    let changed = false;
    for (const t of tabs.values()) {
      if (!t.view || t.id === activeId || t.id === splitId) continue;
      if (now - t.lastActive < limit) continue;
      if (t.view.webContents.isCurrentlyAudible()) continue;
      try {
        win.contentView.removeChildView(t.view);
      } catch {}
      t.view.webContents.close();
      t.view = null;
      t.hibernated = true;
      t.loading = false;
      changed = true;
    }
    if (changed) push();
  }, 30000);
}

function argvTarget(argv) {
  for (const a of argv.slice(1)) {
    if (/^https?:\/\//i.test(a)) return a;
    if (/\.(html?|xhtml|shtml)$/i.test(a) && fs.existsSync(a)) return pathToFileURL(a).href;
  }
  return null;
}

function startupPlan() {
  const argvUrl = argvTarget(process.argv);
  if (argvUrl) return { urls: [argvUrl], active: 0 };
  if (settings.startup === 'continue') {
    try {
      const s = JSON.parse(fs.readFileSync(sessionFile(), 'utf8'));
      if (Array.isArray(s.urls) && s.urls.length) {
        return {
          urls: s.urls.filter((u) => typeof u === 'string'),
          active: Number.isInteger(s.active) ? s.active : 0
        };
      }
    } catch {}
  }
  if (settings.startup === 'urls') {
    const list = settings.startupUrls
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean)
      .map(resolveInput);
    if (list.length) return { urls: list, active: 0 };
  }
  return { urls: [internal.newtab], active: 0 };
}

function createWindow() {
  const o = overlay();
  win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 640,
    minHeight: 400,
    show: false,
    backgroundColor: o.color,
    titleBarStyle: 'hidden',
    titleBarOverlay: o,
    ...(app.isPackaged ? {} : { icon: path.join(__dirname, '..', '..', 'build', 'icon.ico') }),
    webPreferences: {
      preload: path.join(__dirname, 'ui-preload.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.removeMenu();
  win.loadFile(path.join(rendererDir, 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.once('did-finish-load', () => {
    const plan = startupPlan();
    plan.urls.forEach((u) => createTab(u, { activate: false, lazy: true, title: u }));
    const ids = [...tabs.keys()];
    activateTab(ids[Math.min(plan.active, ids.length - 1)] || ids[0]);
  });
  win.webContents.on('before-input-event', handleKey);
  win.on('resize', applyLayout);
  win.on('maximize', applyLayout);
  win.on('unmaximize', applyLayout);
  win.on('closed', () => {
    win = null;
  });
}

ipcMain.on('tab:new', () => createTab(internal.newtab));
ipcMain.on('tab:activate', (e, id) => activateTab(id));
ipcMain.on('tab:close', (e, id) => closeTab(id));
ipcMain.on('nav:go', (e, text) => navigateActive(text));
ipcMain.on('nav:home', () => navigateActive(settings.homepage));
ipcMain.on('nav:back', () => {
  const wc = activeContents();
  if (wc) wc.navigationHistory.goBack();
});
ipcMain.on('nav:forward', () => {
  const wc = activeContents();
  if (wc) wc.navigationHistory.goForward();
});
ipcMain.on('nav:reload', () => {
  const wc = activeContents();
  if (wc) wc.reload();
});
ipcMain.on('menu:open', showMenu);

ipcMain.handle('settings:get', (e) => (fromInternal(e) ? settings : null));
ipcMain.handle('settings:set', (e, patch) => {
  if (!fromInternal(e)) return null;
  const rest = { ...(patch || {}) };
  delete rest.extensions;
  updateSettings(rest);
  return settings;
});
ipcMain.handle('settings:meta', (e) => {
  if (!fromInternal(e)) return null;
  let exts = [];
  try {
    exts = session.defaultSession.extensions.getAllExtensions().map((x) => ({
      id: x.id,
      name: x.name,
      version: x.version,
      path: x.path
    }));
  } catch {}
  return {
    engines: builtinEngines.map(({ id, name }) => ({ id, name })),
    versions: {
      app: app.getVersion(),
      electron: process.versions.electron,
      chrome: process.versions.chrome,
      node: process.versions.node,
      v8: process.versions.v8
    },
    userData: app.getPath('userData'),
    settingsFile: settingsFile(),
    downloads: app.getPath('downloads'),
    defaultBrowser: app.isDefaultProtocolClient('https'),
    updateStatus,
    extensions: exts
  };
});
ipcMain.handle('ext:load', async (e) => {
  if (!fromInternal(e)) return null;
  await loadUnpacked();
  return settings;
});
ipcMain.handle('ext:remove', async (e, p) => {
  if (!fromInternal(e) || typeof p !== 'string') return null;
  try {
    const ext = session.defaultSession.extensions.getAllExtensions().find((x) => x.path === p);
    if (ext) await session.defaultSession.extensions.removeExtension(ext.id);
  } catch {}
  updateSettings({ extensions: settings.extensions.filter((x) => x !== p) });
  return settings;
});
ipcMain.handle('dl:choose', async (e) => {
  if (!fromInternal(e)) return null;
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return null;
  updateSettings({ downloadPath: r.filePaths[0] });
  return settings;
});
ipcMain.handle('path:open', (e) => {
  if (!fromInternal(e)) return null;
  shell.openPath(app.getPath('userData'));
  return true;
});
ipcMain.handle('privacy:clear', async (e) => {
  if (!fromInternal(e)) return false;
  const r = await dialog.showMessageBox(win, {
    type: 'warning',
    buttons: ['Clear data', 'Cancel'],
    defaultId: 1,
    cancelId: 1,
    title: 'Clear browsing data',
    message: 'Clear cookies, site data and cached files?',
    detail: 'You will be signed out of most websites.'
  });
  if (r.response !== 0) return false;
  await clearBrowsingData();
  return true;
});
ipcMain.handle('settings:reset', async (e) => {
  if (!fromInternal(e)) return null;
  const r = await dialog.showMessageBox(win, {
    type: 'warning',
    buttons: ['Reset settings', 'Cancel'],
    defaultId: 1,
    cancelId: 1,
    title: 'Reset settings',
    message: 'Restore all settings to their defaults?'
  });
  if (r.response !== 0) return null;
  const base = { ...defaults };
  delete base.extensions;
  updateSettings(base);
  return settings;
});
ipcMain.handle('settings:export', async (e) => {
  if (!fromInternal(e)) return false;
  const r = await dialog.showSaveDialog(win, { defaultPath: 'argon-settings.json', filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled || !r.filePath) return false;
  const out = { ...settings };
  delete out.extensions;
  try {
    fs.writeFileSync(r.filePath, JSON.stringify(out, null, 2));
    return true;
  } catch {
    return false;
  }
});
ipcMain.handle('settings:import', async (e) => {
  if (!fromInternal(e)) return null;
  const r = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'JSON', extensions: ['json'] }] });
  if (r.canceled || !r.filePaths[0]) return null;
  try {
    const obj = JSON.parse(fs.readFileSync(r.filePaths[0], 'utf8'));
    delete obj.extensions;
    updateSettings(obj);
    return settings;
  } catch {
    return null;
  }
});
ipcMain.handle('browser:default', (e) => {
  if (!fromInternal(e)) return false;
  try {
    app.setAsDefaultProtocolClient('http');
    app.setAsDefaultProtocolClient('https');
  } catch {}
  shell.openExternal('ms-settings:defaultapps?registeredAppUser=Argon');
  return true;
});
ipcMain.handle('update:check', async (e) => {
  if (!fromInternal(e)) return '';
  if (!updater) return 'Updates only work in the installed app';
  try {
    await updater.checkForUpdates();
  } catch {
    updateStatus = 'Update check failed';
  }
  return updateStatus;
});
ipcMain.handle('app:relaunch', (e) => {
  if (!fromInternal(e)) return false;
  app.relaunch();
  app.quit();
  return true;
});

app.on('second-instance', (e, argv) => {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.focus();
  const u = argvTarget(argv);
  if (u) createTab(u);
});

app.on('before-quit', (e) => {
  flushSession();
  if (settings.clearOnExit && !cleaning) {
    e.preventDefault();
    cleaning = true;
    clearBrowsingData().finally(() => app.quit());
  }
});

app.on('window-all-closed', () => app.quit());

app.whenReady().then(async () => {
  nativeTheme.themeSource = settings.theme;
  nativeTheme.on('updated', () => {
    if (win) win.setTitleBarOverlay(overlay());
  });
  const ses = session.defaultSession;
  uaBase = ses.getUserAgent().replace(/\s(?:Electron|argon-browser|Argon)\/[\d.]+/g, '');
  app.userAgentFallback = uaBase;
  applyLanguage();
  setupPermissions();
  setupDownloads();
  try {
    app.setLoginItemSettings({ openAtLogin: settings.openAtLogin });
  } catch {}
  createWindow();
  startHibernation();
  setupUpdater();
  await loadSavedExtensions();
  await initBlocker();
});
